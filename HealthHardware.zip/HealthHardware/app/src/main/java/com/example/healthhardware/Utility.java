package com.example.healthhardware;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.widget.EditText;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import static android.content.Context.MODE_PRIVATE;

class Utility {
    static String[] cameraPermissionsRequired = new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE};
    public static final int PERMISSION_CALLBACK_CONSTANT = 100;
    public static boolean checkCameraPermission(final Context context)
    {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if(currentAPIVersion >= Build.VERSION_CODES.M)
        {
            if (ContextCompat.checkSelfPermission(context, cameraPermissionsRequired[0]) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, cameraPermissionsRequired[1]) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, cameraPermissionsRequired[2]) != PackageManager.PERMISSION_GRANTED ) {
                if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, cameraPermissionsRequired[0]) ||
                        ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, cameraPermissionsRequired[1]) ||
                        ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, cameraPermissionsRequired[2])) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                    alertBuilder.setCancelable(true);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setMessage("Access Camera and Read/Write on disk permission is necessary");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context, cameraPermissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();

                } else {
                    ActivityCompat.requestPermissions((Activity) context, cameraPermissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                }
                return true;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public static boolean checkPermissions(Context context, String... permissions) {
        for (String permission : permissions) {
            int res = context.checkCallingOrSelfPermission(permissions[0]);
            if (res != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }

        return true;
    }


    public static void addPreferences(Context context, String key, Boolean value) {
        SharedPreferences.Editor editor = context.getSharedPreferences("Preferences_", MODE_PRIVATE).edit();
        editor.putBoolean(key, value);
        editor.commit();
    }




    public static void addPreferences(Context context, String key, String value) {
        SharedPreferences.Editor editor = context.getSharedPreferences("Preferences_", MODE_PRIVATE).edit();
        editor.putString(key, value);
        editor.commit();
    }


    public static String getPreferences(Context context, String key) {
        SharedPreferences prefs = context.getSharedPreferences("Preferences_", MODE_PRIVATE);
        String text = prefs.getString(key, "");
        return text;
    }

    public static Double getPreferences(Context context, String key, Double defaultValue) {
        SharedPreferences prefs = context.getSharedPreferences("Preferences_", MODE_PRIVATE);
        String text = prefs.getString(key, "");
        if (text.equals(""))
            return defaultValue;
        return Double.valueOf(text);
    }

    public static int getPreferences(Context context, String key, int defaultValue) {
        SharedPreferences prefs = context.getSharedPreferences("Preferences_", MODE_PRIVATE);
        String text = prefs.getString(key, "");
        if (text.equals(""))
            return defaultValue;
        return Integer.parseInt(text);
    }

    public static void clearPreferenceData(Context context) {
        SharedPreferences.Editor editor = context.getSharedPreferences("Preferences_", MODE_PRIVATE).edit();
        editor.clear();
        editor.commit();
    }

    public static Boolean getPreferences(Context context, String key, boolean defaultValue) {
        SharedPreferences prefs = context.getSharedPreferences("Preferences_", MODE_PRIVATE);
        Boolean text = prefs.getBoolean(key, defaultValue);
        return text;
    }
    public static boolean hasText(EditText editText) {

        String text = editText.getText().toString().trim();
        editText.setError(null);

        // length 0 means there is no text
        if (text.length() == 0) {
            editText.setError("REQUIRED");
            return false;
        }

        return true;
    }

    public static void callFromPhone(Context context,String Phone) {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel",Phone,null));
        context.startActivity(intent);


    }
    public static Bitmap StringToBitMap(String encodedString){
        try{
            byte [] encodeByte= Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        }catch(Exception e){
            e.getMessage();
            return null;
        }
    }
}
