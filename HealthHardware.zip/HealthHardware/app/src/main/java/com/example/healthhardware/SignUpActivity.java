package com.example.healthhardware;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener,VolleyApi.ResponseListener {
    String img = "";
    int flag = 0;
    TextView Login;
    Button signIn;
    RelativeLayout relativeLayout;
    String isEdit = "0", id, isActive;
//    EditText firstnm, lastnm, email, phone, password;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    String image="null";



    private LinearLayout linearLayout1;
    private CircleImageView addPhoto;
    private ImageView imageView1;
    private RelativeLayout relativeLayout1;
    private ImageView imageViewUserIcon;
    private EditText firstName;
    private RelativeLayout relativeLayout4;
    private ImageView imageViewUserIcon1;
    private EditText lastName;
    private RelativeLayout relativeLayout5;
    private ImageView imageViewUserIcon2;
    private EditText emailId;
    private RelativeLayout relativeLayout6;
    private ImageView imageViewUserIcon3;
    private EditText mobNum;
    private RelativeLayout relativeLayout7;
    private ImageView imageViewUserIcon4;
    private EditText passwordReg;
    private CardView SignInCard;
    private ImageView imageView2;
    private TextView LogIn,signup_txt;
    private int flagApi=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        initView();

        if(getIntent().getStringExtra("isEdit")!=null){

            mobNum.setEnabled(false);
            mobNum.setText(Utility.getPreferences(this,Singleton.mobile));
            firstName.setText(Utility.getPreferences(this,Singleton.first_name));
            lastName.setText(Utility.getPreferences(this,Singleton.last_name));
            emailId.setText(Utility.getPreferences(this,Singleton.email));
            passwordReg.setText(Utility.getPreferences(this,Singleton.password));
            System.out.println("dsafs ::::: "+Utility.getPreferences(this,Singleton.photo));
            if(!Utility.getPreferences(this,Singleton.photo).trim().equalsIgnoreCase("")){
                setPhoto(Utility.StringToBitMap(Utility.getPreferences(this,Singleton.photo)));
                image = Utility.getPreferences(this,Singleton.photo);
            }
            signup_txt.setText("UPDATE");

        }
    }

    private void initView() {
        linearLayout1 = findViewById(R.id.linearLayout1);
        addPhoto = findViewById(R.id.add_photo);
        addPhoto.setOnClickListener(this);
        imageView1 = findViewById(R.id.imageView1);
        relativeLayout1 = findViewById(R.id.relativeLayout1);
        imageViewUserIcon = findViewById(R.id.imageView_userIcon);
        firstName = findViewById(R.id.first_name);
        relativeLayout4 = findViewById(R.id.relativeLayout4);
        imageViewUserIcon1 = findViewById(R.id.imageView_userIcon1);
        lastName = findViewById(R.id.last_name);
        relativeLayout5 = findViewById(R.id.relativeLayout5);
        imageViewUserIcon2 = findViewById(R.id.imageView_userIcon2);
        emailId = findViewById(R.id.email_id);
        relativeLayout6 = findViewById(R.id.relativeLayout6);
        imageViewUserIcon3 = findViewById(R.id.imageView_userIcon3);
        mobNum = findViewById(R.id.mob_num);
        relativeLayout7 = findViewById(R.id.relativeLayout7);
        imageViewUserIcon4 = findViewById(R.id.imageView_userIcon4);
        passwordReg = findViewById(R.id.password_reg);
        SignInCard = findViewById(R.id.SignIn_card);
        SignInCard.setOnClickListener(this);
        imageView2 = findViewById(R.id.imageView2);
        LogIn = findViewById(R.id.Log_in);
        signup_txt = findViewById(R.id.sign_up_txt);
        LogIn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.SignIn_card:

                if(checkValidation()){
                    if(getIntent().getStringExtra("isEdit")!=null){
                        flagApi =1;
                        VolleyApi.getInstance().registerUser(SignUpActivity.this,SignUpActivity.this,firstName.getText().toString(),
                                lastName.getText().toString(),
                                passwordReg.getText().toString(),
                                mobNum.getText().toString(),
                                image,1);

                    }else{
                        flagApi =2;
                        VolleyApi.getInstance().registerUser(SignUpActivity.this,SignUpActivity.this,firstName.getText().toString(),
                                lastName.getText().toString(),
                                passwordReg.getText().toString(),
                                mobNum.getText().toString(),
                                image,0);
                    }




                }
                break;
            case R.id.Log_in:
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                break;
            case R.id.add_photo:
                boolean rs = Utility.checkCameraPermission(SignUpActivity.this);
                System.out.println("::::::::::::::::: :: " + rs);
                if (rs) {
                    chooseProfilePic();
                }

                break;

        }

    }

    private boolean checkValidation() {

        boolean ret = true;
        if (!Utility.hasText(mobNum)) ret = false;
        if (!Utility.hasText(firstName)) ret = false;
        if (!Utility.hasText(lastName)) ret = false;
        if (!Utility.hasText(passwordReg)) ret = false;
        return ret;


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 100:
                if (resultCode == RESULT_OK) {
                }
                break;

            default:

                if (resultCode == Activity.RESULT_OK) {
                    if (requestCode == SELECT_FILE)
                        onSelectFromGalleryResult(data);
                    else if (requestCode == REQUEST_CAMERA)
                        onCaptureImageResult(data);

                }

                break;


        }

    }
    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }


    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }
    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {

        Bitmap bm = null;
        if (data != null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        img = getStringImage(bm);
        setPhoto(bm);
        image =img;
//        Singleton.img = img;

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 100:
               /* if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (userChoosenTask.equals("Take Photo"))
                        cameraIntent();
                    else if (userChoosenTask.equals("Choose from Library"))
                        galleryIntent();
                } else {
                    //code for deny
                }*/
                break;
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        img = getStringImage(thumbnail);
        setPhoto(thumbnail);
        image =img;
//        Singleton.img = img;

    }
    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 20, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;

    }


    private void setPhoto(Bitmap bitmap) {
        addPhoto.setImageBitmap(bitmap);
        System.out.println("imageee :" + img);

    }

    public void chooseProfilePic() // replcae method name with chooseProfilePic

    {
        final CharSequence[] items = {"Camera", "Gallery"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Profile Picture");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                boolean result = Utility.checkPermissions(getApplicationContext());

                if (items[item].equals("Camera")) {
                    userChoosenTask = "Camera";
                    if (result)
                        cameraIntent();

                } else if (items[item].equals("Gallery")) {
                    userChoosenTask = "Gallery";
                    if (result)
                        galleryIntent();

                }
            }
        });
        builder.show();
    }


    @Override
    public void _onResponseError(Throwable e) {
        Toast.makeText(this, "Something went wrong !!", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void _onNext(String obj) {
        if(flagApi==3){

            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("login");
                //int len = jArray.length();
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);

                    System.out.println("sdfsdfd :::::::: " + json_data.toString());


                    Utility.addPreferences(this, Singleton.id, json_data.getString("id"));
                    Utility.addPreferences(this, Singleton.first_name, json_data.getString("first_name"));
                    Utility.addPreferences(this, Singleton.last_name, json_data.getString("last_name"));
                    Utility.addPreferences(this, Singleton.mobile, json_data.getString("mobile"));
                    Utility.addPreferences(this, Singleton.password, json_data.getString("password"));
                    Utility.addPreferences(this, Singleton.photo, json_data.getString("photo"));
                    Utility.addPreferences(this, Singleton.isLogin, "1");

                    Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);

                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "nnumber or password invalid", Toast.LENGTH_SHORT).show();
            }



        }else {


            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("msg");
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);
                    if (json_data.getString("status").equalsIgnoreCase("200")) {
                        Toast.makeText(this, "Success !!", Toast.LENGTH_SHORT).show();
                        if (flagApi == 2) {
                            startActivity(new Intent(SignUpActivity.this, OtpActivity.class).putExtra("number", mobNum.getText().toString()).putExtra("psw", passwordReg.getText().toString()));
                            finish();
                        } else {
                            flagApi = 3;

                            VolleyApi.getInstance().loginUser(this, this,
                                    mobNum.getText().toString().trim(),
                                    passwordReg.getText().toString().trim(), true);

//
                        }


                    }
                }

            } catch (
                    JSONException e) {
                e.printStackTrace();
                Toast.makeText(this, "Something went wrong !!", Toast.LENGTH_SHORT).show();

            }
        }
    }
}
