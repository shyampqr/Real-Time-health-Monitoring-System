package com.example.healthhardware;

import android.animation.Animator;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.airbnb.lottie.LottieAnimationView;

import org.json.JSONArray;
import org.json.JSONObject;

public class OtpActivity extends AppCompatActivity implements View.OnClickListener, VolleyApi.ResponseListener {
    EditText otp_one, otp_two, otp_three, otp_four, otp_five, otp_six;
    TextView title, describ, wait, enter_another, termCondition;
    CardView submit;
    LinearLayout phonely, otplayout;
    ProgressBar pro_otp;
    LottieAnimationView done_complete;
    private String userNumber;
    private String userpsw;
    private String OTP;
    private int flagapi = 0;
    String requestId;
    String number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        intiView();
        if (getIntent().getStringExtra("number") != null) {
            userNumber = getIntent().getStringExtra("number");
            userpsw = getIntent().getStringExtra("psw");
            pro_otp.setVisibility(View.VISIBLE);
            flagapi=1;
            VolleyApi.getInstance().loginUser(this, this, userNumber, userpsw, false);
        }

        if(getIntent().getStringExtra("call")!=null){
            number =getIntent().getStringExtra("call");
              requestId=getIntent().getStringExtra("requestID");
            pro_otp.setVisibility(View.VISIBLE);
            flagapi=2;
            VolleyApi.getInstance().getOtpRqs(this, this, requestId, number);



        }

    }

    private void intiView() {

        termCondition = findViewById(R.id.termCondition);
        done_complete = findViewById(R.id.done_anim);
        pro_otp = findViewById(R.id.pro_otp);

        title = findViewById(R.id.tct2);
        describ = findViewById(R.id.tct);

        otplayout = findViewById(R.id.ly7);


        wait = findViewById(R.id.wait);
        otp_one = findViewById(R.id.otp_one);
        otp_two = findViewById(R.id.otp_two);
        otp_three = findViewById(R.id.otp_three);
        otp_four = findViewById(R.id.otp_four);
        otp_five = findViewById(R.id.otp_five);
        otp_six = findViewById(R.id.otp_six);
        submit = findViewById(R.id.verify_card);
        submit.setOnClickListener(this);

        otp_one.addTextChangedListener(new GenericTextWatcher(otp_one));
        otp_two.addTextChangedListener(new GenericTextWatcher(otp_two));
        otp_three.addTextChangedListener(new GenericTextWatcher(otp_three));
        otp_four.addTextChangedListener(new GenericTextWatcher(otp_four));
        otp_five.addTextChangedListener(new GenericTextWatcher(otp_five));
        otp_six.addTextChangedListener(new GenericTextWatcher(otp_six));

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.verify_card:



                String verificationCode = otp_one.getText().toString().trim() + otp_two.getText().toString().trim() + otp_three.getText().toString().trim() + otp_four.getText().toString().trim() + otp_five.getText().toString().trim() + otp_six.getText().toString().trim();


                if (verificationCode.equalsIgnoreCase(OTP)) {
                    done_complete.setVisibility(View.VISIBLE);
                    done_complete.playAnimation();
                    done_complete.addAnimatorListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {

                            if(flagapi==2){

                                flagapi=3;
                                VolleyApi.getInstance().updateRequest(OtpActivity.this,OtpActivity.this,"1",requestId);
                            }else {
                                Utility.addPreferences(OtpActivity.this, Singleton.isLogin, "1");
                                startActivity(new Intent(OtpActivity.this, MainActivity.class));
                            }




                        }

                        @Override
                        public void onAnimationCancel(Animator animation) {

                        }

                        @Override
                        public void onAnimationRepeat(Animator animation) {

                        }
                    });
                }
                break;
        }

    }

    @Override
    public void _onResponseError(Throwable e) {


    }

    @Override
    public void _onNext(String obj) {


        pro_otp.setVisibility(View.INVISIBLE);

        if(flagapi==2){


            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("data");
                //JSONArray jArray2 = obj1.getJSONArray("request_data");
                //int len = jArray.length();
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);

                    if(json_data.optString("mobile").equalsIgnoreCase(number)){

                        OTP= json_data.getString("otp");

                    }

                    System.out.println("sdfsdfd :::::::: " + json_data.toString());

                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "No Data Found !!", Toast.LENGTH_SHORT).show();
            }

        }else if(flagapi ==1) {
            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("login");
                //int len = jArray.length();
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);

                    OTP = json_data.getString("otp");

                    System.out.println("c :::::::: " + json_data.toString());


                    Utility.addPreferences(this, Singleton.id, json_data.getString("id"));
                    Utility.addPreferences(this, Singleton.first_name, json_data.getString("first_name"));
                    Utility.addPreferences(this, Singleton.last_name, json_data.getString("last_name"));
                    Utility.addPreferences(this, Singleton.mobile, json_data.getString("mobile"));
                    Utility.addPreferences(this, Singleton.password, json_data.getString("password"));
                    Utility.addPreferences(this, Singleton.photo, json_data.getString("photo"));
                    Utility.addPreferences(this, Singleton.isLogin, "1");


                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "nnumber or password invalid", Toast.LENGTH_SHORT).show();
            }
        }else if (flagapi==3){

            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("msg");
                //JSONArray jArray2 = obj1.getJSONArray("request_data");
                //int len = jArray.length();
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);

                    if(json_data.optString("status").equalsIgnoreCase("200")){
                        startActivity(new Intent(OtpActivity.this, MainActivity.class));

                    }


                }
                ;
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Something went wrong !!", Toast.LENGTH_SHORT).show();
            }

        }


    }


    public class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // TODO Auto-generated method stub
            String text = editable.toString();
            switch (view.getId()) {
                case R.id.otp_one:
                    if (text.length() == 1) {
                        System.out.println("asfdasfsad");
                        otp_two.requestFocus();
                    }

                    break;
                case R.id.otp_two:
                    if (text.length() == 1) {
                        otp_three.requestFocus();
                    } else if (text.length() == 0) {
                        otp_one.requestFocus();
                    }

                    break;
                case R.id.otp_three:

                    if (text.length() == 1) {
                        otp_four.requestFocus();
                    } else if (text.length() == 0) {
                        otp_two.requestFocus();
                    }
                    break;
                case R.id.otp_four:
                    if (text.length() == 1) {
                        otp_five.requestFocus();
                    } else if (text.length() == 0) {
                        otp_three.requestFocus();
                    }
                    break;
                case R.id.otp_five:
                    if (text.length() == 1) {
                        otp_six.requestFocus();
                    } else if (text.length() == 0) {
                        otp_four.requestFocus();
                    }
                    break;
                case R.id.otp_six:
                    if (text.length() == 0) {
                        otp_five.requestFocus();
                    }
                    break;
            }
        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

            // TODO Auto-generated method stub
        }


    }

}
