package com.example.healthhardware;

class main_data {
    String id;
    String number;

    public main_data(String id, String number, String describtion, String status) {
        this.id = id;
        this.number = number;
        this.describtion = describtion;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDescribtion() {
        return describtion;
    }

    public void setDescribtion(String describtion) {
        this.describtion = describtion;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    String describtion;
    String  status;
}
