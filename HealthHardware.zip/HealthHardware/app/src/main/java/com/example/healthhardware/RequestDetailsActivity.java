package com.example.healthhardware;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class RequestDetailsActivity extends AppCompatActivity implements VolleyApi.ResponseListener {
    RecyclerView recycler_view1;
    Button button1,button2;
    String requestID,call;
    ArrayList<RequestData> requestData =new ArrayList<>();
    int flag=0;
    private int flagapi =0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);
        recycler_view1 = findViewById(R.id.recycler_view1);
        button1 = findViewById(R.id.close);
        button2 = findViewById(R.id.call_icon);
        requestID = getIntent().getStringExtra("requestID");
        call = getIntent().getStringExtra("call");
        System.out.println(">>>>>WC>>>>> "+requestID);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:"+call));
                startActivity(callIntent);
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeRequest();
            }
        });

        VolleyApi.getInstance().getRequestData(this,this,requestID);

    }

    private void closeRequest() {
        flagapi=2;
        VolleyApi.getInstance().sendMsg(this,this,call,requestID);



    }

    @Override
    public void _onResponseError(Throwable e) {

    }

    @Override
    public void _onNext(String obj) {
        if(flagapi==2){

            requestData.clear();
            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("msg");
                //JSONArray jArray2 = obj1.getJSONArray("request_data");
                //int len = jArray.length();
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);

                    if(json_data.optString("status").equalsIgnoreCase("200")){


                        startActivity(new Intent(this,OtpActivity.class)
                                .putExtra("call",""+call)
                                .putExtra("requestID",""+requestID));

                        button1.setVisibility(View.GONE);



                    }


                }
;
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Something went wrong !!", Toast.LENGTH_SHORT).show();
            }

        }else {
            requestData.clear();
            try {
                JSONObject obj1 = new JSONObject(obj);
                JSONArray jArray = obj1.getJSONArray("data");
                //JSONArray jArray2 = obj1.getJSONArray("request_data");
                //int len = jArray.length();
                for (int i = 0; i < jArray.length(); i++) {

                    JSONObject json_data = jArray.getJSONObject(i);

                    System.out.println("sdfsdfd :::::::: " + json_data.toString());
                    requestData .add( new RequestData(""
                            +json_data.optString("name"),
                            "" +json_data.optString("value")));
                }

                RequestDataAdapter requestDataAdapter = new RequestDataAdapter(requestData, 1, R.layout.main_item, false, this);

                recycler_view1.setAdapter(requestDataAdapter);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "nnumber or password invalid", Toast.LENGTH_SHORT).show();
            }
        }


    }
}
