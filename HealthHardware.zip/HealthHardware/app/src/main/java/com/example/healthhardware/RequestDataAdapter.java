package com.example.healthhardware;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class RequestDataAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    main_data vehicleName;
    private Activity context;
    private List<RequestData> main_data;
    private int mLayoutResourceId;



    public RequestDataAdapter(List<RequestData> vehicleNames, int flag, int mLayoutResourceId, Boolean isSelectedLayout, Activity context) {
        this.main_data = vehicleNames;
        this.mLayoutResourceId = mLayoutResourceId;

        this.context = context;

    }

    private static void displayAlert(final Activity context, String title, String msg) {
        new AlertDialog.Builder(context).setMessage(msg).setTitle(title).setCancelable(true)
                .setNegativeButton("Okay", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        dialog.dismiss();

                    }
                }).show();
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_details, parent, false);


        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {

        final MyViewHolder holder1 = (MyViewHolder) holder;
      //holder1.description.setText(R.string.dummy);
      holder1.name.setText(main_data.get(position).getName());
      holder1.value.setText(main_data.get(position).getValue());

     /* if (main_data.get(position).getStatus().equalsIgnoreCase("0")){
          holder1.status_icon.setColorFilter(ContextCompat.getColor(context, R.color.red));
          holder1.status_text.setText("Pending");
      }else {
          holder1.status_icon.setColorFilter(ContextCompat.getColor(context, R.color.colorPrimary));
          holder1.status_text.setText("Completed");
      }

      holder1.itemView.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {

              context.startActivity(new Intent(view.getContext(),RequestDetailsActivity.class
              ).putExtra("requestID",main_data.get(position).getId()));
          }
      });
*/

    }

    @Override
    public int getItemCount() {
        return main_data.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView value, name;
        View convertView;


        MyViewHolder(View view) {
            super(view);
            convertView = view;
            value = view.findViewById(R.id.value);

            name = (TextView) view.findViewById(R.id.name);


        }
    }


}