package com.example.healthhardware;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;



public class MainAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    main_data vehicleName;
    private Activity context;
    private List<main_data> main_data;
    private int mLayoutResourceId;



    public MainAdapter(List<main_data> vehicleNames, int flag, int mLayoutResourceId, Boolean isSelectedLayout, Activity context) {
        this.main_data = vehicleNames;
        this.mLayoutResourceId = mLayoutResourceId;

        this.context = context;

    }

    private static void displayAlert(final Activity context, String title, String msg) {
        new AlertDialog.Builder(context).setMessage(msg).setTitle(title).setCancelable(true)
                .setNegativeButton("Okay", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        dialog.dismiss();

                    }
                }).show();
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(mLayoutResourceId, parent, false);


        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {

        final MyViewHolder holder1 = (MyViewHolder) holder;
        final main_data ed =main_data.get(position);
      //holder1.descriptiomain_datan.setText(R.string.dummy);
      holder1.number.setText(main_data.get(position).getNumber());
      if (main_data.get(position).getStatus().equalsIgnoreCase("0")){
          holder1.status_icon.setColorFilter(ContextCompat.getColor(context, R.color.red));
          holder1.status_text.setText("Pending");
      }else {
          holder1.status_icon.setColorFilter(ContextCompat.getColor(context, R.color.colorPrimary));
          holder1.status_text.setText("Completed");
      }

      holder1.call_icon.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Utility.callFromPhone(
                      context,main_data.get(position).getNumber()
              );
//              Intent callIntent = new Intent(Intent.ACTION_CALL);
//              callIntent.setData(Uri.parse("tel:"+main_data.get(position).getNumber()));
//              view.getContext().startActivity(callIntent);
          }
      });

      holder1.itemView.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              System.out.println(ed.getNumber()+ "   1234d2ed2  ::: "+ed.getId());

              context.startActivity(new Intent(view.getContext(),RequestDetailsActivity.class)
                      .putExtra("call",""+ed.getNumber())
                      .putExtra("requestID",ed.getId()));
          }
      });


    }

    @Override
    public int getItemCount() {
        return main_data.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView number, description, status_text;
        ImageView status_icon, call_icon;
        View convertView;


        MyViewHolder(View view) {
            super(view);
            convertView = view;
            number = view.findViewById(R.id.number_item);

            description = (TextView) view.findViewById(R.id.description);
            status_text = (TextView) view.findViewById(R.id.status_text);
            status_icon = view.findViewById(R.id.status_img);
            call_icon = view.findViewById(R.id.call_icon);

        }
    }


}