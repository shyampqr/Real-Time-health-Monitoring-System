package com.example.healthhardware;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements VolleyApi.ResponseListener{

    private  MainAdapter mAdapter;
    private RelativeLayout toolbarRl;
    private RecyclerView recyclerView1;
    ArrayList<main_data> main_data = new ArrayList<>();
    TextView no_data;
    ImageView logout,profile_edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        System.out.println("asdfsafs >>>>> "+Utility.getPreferences(this,Singleton.id));
        VolleyApi.getInstance().getRequest(this,this,Utility.getPreferences(this,Singleton.id));
    }

    private void initView() {
        toolbarRl = findViewById(R.id.toolbar_rl);
        recyclerView1 = findViewById(R.id.recycler_view1);
        logout = findViewById(R.id.logout_ic);
        profile_edit = findViewById(R.id.profile);
        no_data = findViewById(R.id.no_data);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utility.clearPreferenceData(MainActivity.this);
                startActivity(new Intent(MainActivity.this, LoginActivity.class));



            }
        });
        profile_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,SignUpActivity.class).putExtra("isEdit","1"));
            }
        });

       /* for(int i =0;i<10;i++){

            main_data .add( new main_data("+91 9556674224",""+R.string.dummy,""));


        }*/

    }

    @Override
    public void _onResponseError(Throwable e) {

    }

    @Override
    public void _onNext(String obj) {
        main_data.clear();
        no_data.setVisibility(View.GONE);
        try {
            JSONObject obj1 = new JSONObject(obj);
            JSONArray jArray = obj1.getJSONArray("data");
            //JSONArray jArray2 = obj1.getJSONArray("request_data");
            //int len = jArray.length();
            for (int i = 0; i < jArray.length(); i++) {

                JSONObject json_data = jArray.getJSONObject(i);

                System.out.println("sdfsdfd :::::::: " + json_data.toString());
                main_data .add( new main_data(
                        ""+json_data.optString("requesti_d"),
                        "" +json_data.optString("mobile"),
                        "",
                        ""+json_data.optString("status")));
            }

            mAdapter = new MainAdapter(main_data, 1, R.layout.main_item, false, this);

            recyclerView1.setAdapter(mAdapter);
        } catch (Exception e) {
            e.printStackTrace();
            no_data.setVisibility(View.VISIBLE);
            Toast.makeText(this, "No Data Found !!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        VolleyApi.getInstance().getRequest(this,this,Utility.getPreferences(this,Singleton.id));

    }
}
