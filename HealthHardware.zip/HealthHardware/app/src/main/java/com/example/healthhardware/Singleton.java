package com.example.healthhardware;

public class Singleton {

    public static String id="id";
    public static String last_name="last_name";
    public static String mobile="mobile";
    public static String first_name="first_name";
    public static String password="password";
    public static String photo="photo";
    public static String isLogin="isLogin";
    public static String email = "email";
}