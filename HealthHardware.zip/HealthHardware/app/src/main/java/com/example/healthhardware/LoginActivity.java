package com.example.healthhardware;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.airbnb.lottie.LottieAnimationView;

import org.json.JSONArray;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, VolleyApi.ResponseListener {

    private LinearLayout linearLayout1;
    private LottieAnimationView animationView;
    private ImageView imageView1;
    private RelativeLayout relativeLayout1;
    private ImageView imageViewUserIcon;
    private EditText number;
    private RelativeLayout relativeLayout2;
    private ImageView imageViewPasswordIcon;
    private EditText password;
    private RelativeLayout relativeLayout3;
    private CheckBox remember;
    private CardView LoginCard;
    private ImageView imageView2;
    private TextView signUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (Utility.getPreferences(this, Singleton.isLogin).equalsIgnoreCase("1")) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
        } else {
            initView();
        }


    }

    private void initView() {
        linearLayout1 = findViewById(R.id.linearLayout1);
        animationView = findViewById(R.id.animation_view);
        imageView1 = findViewById(R.id.imageView1);
        relativeLayout1 = findViewById(R.id.relativeLayout1);
        imageViewUserIcon = findViewById(R.id.imageView_userIcon);
        number = findViewById(R.id.number);
        relativeLayout2 = findViewById(R.id.relativeLayout2);
        imageViewPasswordIcon = findViewById(R.id.imageView_passwordIcon);
        password = findViewById(R.id.password);
        relativeLayout3 = findViewById(R.id.relativeLayout3);
        remember = findViewById(R.id.remember);
        LoginCard = findViewById(R.id.Login_card);
        LoginCard.setOnClickListener(this);
        imageView2 = findViewById(R.id.imageView2);
        signUp = findViewById(R.id.sign_up);
        signUp.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.Login_card:
                // startActivity(new Intent(LoginActivity.this, MainActivity.class));
                if (number.getText().toString().length() == 10 && !password.getText().toString().isEmpty()) {
                    VolleyApi.getInstance().loginUser(this, this,
                            number.getText().toString().trim(),
                            password.getText().toString().trim(), true);

                } else {
                    Toast.makeText(this, "Please enter number or password ", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.sign_up:
                startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
                break;
        }

    }

    @Override
    public void _onResponseError(Throwable e) {

    }

    @Override
    public void _onNext(String obj) {
        try {
            JSONObject obj1 = new JSONObject(obj);
            JSONArray jArray = obj1.getJSONArray("login");
            //int len = jArray.length();
            for (int i = 0; i < jArray.length(); i++) {

                JSONObject json_data = jArray.getJSONObject(i);

                System.out.println("sdfsdfd :::::::: " + json_data.toString());


                Utility.addPreferences(this, Singleton.id, json_data.getString("id"));
                Utility.addPreferences(this, Singleton.first_name, json_data.getString("first_name"));
                Utility.addPreferences(this, Singleton.last_name, json_data.getString("last_name"));
                Utility.addPreferences(this, Singleton.mobile, json_data.getString("mobile"));
                Utility.addPreferences(this, Singleton.password, json_data.getString("password"));
                Utility.addPreferences(this, Singleton.photo, json_data.getString("photo"));
                Utility.addPreferences(this, Singleton.isLogin, "1");

                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "nnumber or password invalid", Toast.LENGTH_SHORT).show();
        }

    }
}
